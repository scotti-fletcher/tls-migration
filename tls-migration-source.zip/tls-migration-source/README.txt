Content
Sources: [tls-migration-source]
Parsers: [tls-migration-parser]
Fields: [tls-api-username, tls-client-ip, tls-form-username, tls-host, tls-http-method, tls-request-uri, tls-request-user-agent, tls-version]

Reference
Functions: [Geolocation]
Fields: [cityclnt, continentclnt, continentcodeclnt, countryclnt, countrycodeclnt, geolocclnt, mbody, regionclnt, regioncodeclnt, time]
